#!/usr/bin/env python3
"""
Test script for the modular NASA Lunar Pipeline

This script tests the basic functionality of each module to ensure
the modular structure is working correctly.
"""

import sys
import logging
from pathlib import Path

# Setup logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

def test_imports():
    """Test that all modules can be imported correctly"""
    logger.info("Testing module imports...")
    
    try:
        from src.enums import DataProductType, CameraType
        logger.info("✅ Enums imported successfully")
        
        from src.models import ImageMetadata
        logger.info("✅ Models imported successfully")
        
        from src.preprocessor import LunarImagePreprocessor
        logger.info("✅ Preprocessor imported successfully")
        
        from src.corrector import RadiometricCorrector, GeometricCorrector
        logger.info("✅ Correctors imported successfully")
        
        from src.processor import SuperResolutionProcessor, ImageStitcher
        logger.info("✅ Processors imported successfully")
        
        from src.parallel import ParallelProcessor
        logger.info("✅ Parallel processor imported successfully")
        
        from src.pipeline import LunarDLTPipeline, create_default_config
        logger.info("✅ Pipeline imported successfully")
        
        return True
        
    except ImportError as e:
        logger.error(f"❌ Import failed: {e}")
        return False

def test_enums():
    """Test enum functionality"""
    logger.info("Testing enums...")
    
    try:
        from src.enums import DataProductType, CameraType
        
        # Test enum values
        assert DataProductType.RAW.value == "raw"
        assert DataProductType.CALIBRATION.value == "calibration"
        assert DataProductType.DERIVED.value == "derived"
        
        assert CameraType.WAC.value == "wac"
        assert CameraType.NAC.value == "nac"
        
        logger.info("✅ Enums working correctly")
        return True
        
    except Exception as e:
        logger.error(f"❌ Enum test failed: {e}")
        return False

def test_models():
    """Test data models"""
    logger.info("Testing data models...")
    
    try:
        from src.enums import CameraType, DataProductType
        from src.models import ImageMetadata
        
        # Create test metadata
        metadata = ImageMetadata(
            product_id="test_image",
            camera_type=CameraType.WAC,
            product_type=DataProductType.RAW,
            timestamp="2025-01-01T00:00:00",
            resolution=(1024, 1024),
            file_path="/path/to/test/image.png"
        )
        
        # Test attributes
        assert metadata.product_id == "test_image"
        assert metadata.camera_type == CameraType.WAC
        assert metadata.resolution == (1024, 1024)
        
        logger.info("✅ Data models working correctly")
        return True
        
    except Exception as e:
        logger.error(f"❌ Data model test failed: {e}")
        return False

def test_config_creation():
    """Test configuration file creation"""
    logger.info("Testing configuration creation...")
    
    try:
        from src.pipeline import create_default_config
        
        # Create config
        config = create_default_config()
        
        # Check if config file exists
        config_file = Path("config.json")
        assert config_file.exists(), "Config file should be created"
        
        # Check config structure
        assert "batch_size" in config
        assert "super_resolution" in config
        assert config["batch_size"] == 8
        
        logger.info("✅ Configuration creation working correctly")
        return True
        
    except Exception as e:
        logger.error(f"❌ Configuration test failed: {e}")
        return False

def test_component_initialization():
    """Test component initialization"""
    logger.info("Testing component initialization...")
    
    try:
        from src.corrector import RadiometricCorrector, GeometricCorrector
        from src.parallel import ParallelProcessor
        
        # Test RadiometricCorrector
        radiometric_corrector = RadiometricCorrector()
        assert radiometric_corrector is not None
        
        # Test GeometricCorrector with dummy params
        dummy_params = {
            'wac': {'fx': 1000, 'fy': 1000, 'cx': 512, 'cy': 512, 'k1': 0, 'k2': 0, 'p1': 0, 'p2': 0},
            'nac': {'fx': 2000, 'fy': 2000, 'cx': 1024, 'cy': 1024, 'k1': 0, 'k2': 0, 'p1': 0, 'p2': 0}
        }
        geometric_corrector = GeometricCorrector(dummy_params)
        assert geometric_corrector is not None
        
        # Test ParallelProcessor
        parallel_processor = ParallelProcessor()
        assert parallel_processor is not None
        
        logger.info("✅ Component initialization working correctly")
        return True
        
    except Exception as e:
        logger.error(f"❌ Component initialization test failed: {e}")
        return False

def main():
    """Run all tests"""
    logger.info("Starting modular pipeline tests...")
    
    tests = [
        ("Module Imports", test_imports),
        ("Enums", test_enums),
        ("Data Models", test_models),
        ("Configuration", test_config_creation),
        ("Component Initialization", test_component_initialization)
    ]
    
    passed = 0
    total = len(tests)
    
    for test_name, test_func in tests:
        logger.info(f"\n{'='*50}")
        logger.info(f"Running test: {test_name}")
        logger.info(f"{'='*50}")
        
        try:
            if test_func():
                passed += 1
                logger.info(f"✅ {test_name} PASSED")
            else:
                logger.error(f"❌ {test_name} FAILED")
        except Exception as e:
            logger.error(f"❌ {test_name} FAILED with exception: {e}")
    
    logger.info(f"\n{'='*50}")
    logger.info(f"TEST RESULTS: {passed}/{total} tests passed")
    logger.info(f"{'='*50}")
    
    if passed == total:
        logger.info("🎉 All tests passed! The modular structure is working correctly.")
        return 0
    else:
        logger.error(f"❌ {total - passed} tests failed. Please check the errors above.")
        return 1

if __name__ == "__main__":
    sys.exit(main()) 