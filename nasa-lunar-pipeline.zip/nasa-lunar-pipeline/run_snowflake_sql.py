import os
from dotenv import load_dotenv
import snowflake.connector

# Load environment variables from .env
load_dotenv()

# Remove quotes if present in env vars
def clean_env(var):
    val = os.getenv(var)
    if val and val.startswith('"') and val.endswith('"'):
        return val[1:-1]
    return val

# Snowflake connection parameters
account = clean_env('SNOWFLAKE_ACCOUNT')
user = clean_env('SNOWFLAKE_USER')
password = clean_env('SNOWFLAKE_PASSWORD')
role = clean_env('SNOWFLAKE_ROLE')
warehouse = clean_env('SNOWFLAKE_WAREHOUSE')
database = clean_env('SNOWFLAKE_DATABASE')

# Connect to Snowflake
def get_connection():
    return snowflake.connector.connect(
        user=user,
        password=password,
        account=account,
        role=role,
        warehouse=warehouse,
        database=database
    )

# Read SQL file
with open('sql/snowflake_schema.sql', 'r') as f:
    sql_script = f.read()

# Split into individual statements (naive split by semicolon)
statements = [stmt.strip() for stmt in sql_script.split(';') if stmt.strip()]

# Execute statements
conn = get_connection()
cur = conn.cursor()
try:
    for stmt in statements:
        print(f'Executing: {stmt[:60]}...')
        cur.execute(stmt)
    print('All statements executed successfully.')
finally:
    cur.close()
    conn.close()