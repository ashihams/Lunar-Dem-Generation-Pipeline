#!/bin/bash
# NASA Lunar Pipeline - HPC Usage Examples
# This script demonstrates various ways to submit jobs to HPC clusters

echo "=========================================="
echo "NASA Lunar Pipeline - HPC Usage Examples"
echo "=========================================="

# Make all scripts executable
chmod +x *.sh

echo "🚀 Example 1: Submit a basic Slurm job"
echo "Command: sbatch slurm_submit.sh"
echo "This will submit a single-node job with 16 CPUs and 2 GPUs"
echo ""

echo "🚀 Example 2: Submit a basic PBS job"
echo "Command: qsub pbs_submit.sh"
echo "This will submit a single-node PBS job with 16 CPUs and 2 GPUs"
echo ""

echo "🚀 Example 3: Submit a multi-node Slurm job"
echo "Command: sbatch slurm_multi_node.sh"
echo "This will submit a 4-node job with MPI support"
echo ""

echo "🚀 Example 4: Use the interactive job submission helper"
echo "Command: ./submit_job.sh -t slurm -n 1 -c 32 -g 4 -e your.email@institution.edu"
echo "This creates and submits a custom job with 32 CPUs and 4 GPUs"
echo ""

echo "🚀 Example 5: Submit a high-memory job"
echo "Command: ./submit_job.sh -t slurm -n 1 -c 64 -g 8 -m 256G -e your.email@institution.edu"
echo "This creates a job with 64 CPUs, 8 GPUs, and 256GB memory"
echo ""

echo "🚀 Example 6: Submit a multi-node compute job"
echo "Command: ./submit_job.sh -t multi -n 8 -c 16 -g 1 -e your.email@institution.edu"
echo "This creates an 8-node job for large-scale processing"
echo ""

echo "=========================================="
echo "Before submitting jobs, make sure to:"
echo "1. Update email addresses in the scripts"
echo "2. Adjust module versions for your cluster"
echo "3. Modify partition names if needed"
echo "4. Set appropriate data paths"
echo "5. Copy your lunar images to the input directory"
echo "=========================================="

echo ""
echo "📋 Quick Commands Reference:"
echo ""

echo "# Check job status (Slurm)"
echo "squeue -u \$USER"
echo ""

echo "# Check job status (PBS)"
echo "qstat -u \$USER"
echo ""

echo "# Monitor GPU usage"
echo "nvidia-smi"
echo ""

echo "# View job output"
echo "tail -f logs/nasa_lunar_<job_id>.out"
echo ""

echo "# Cancel a job (Slurm)"
echo "scancel <job_id>"
echo ""

echo "# Cancel a job (PBS)"
echo "qdel <job_id>"
echo ""

echo "=========================================="
echo "For detailed information, see: README.md"
echo "==========================================" 