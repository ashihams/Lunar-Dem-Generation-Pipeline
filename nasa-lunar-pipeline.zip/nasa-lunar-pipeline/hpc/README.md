# NASA Lunar Pipeline - HPC Deployment Guide

This guide explains how to deploy and run the NASA Lunar Pipeline on High Performance Computing (HPC) clusters using Slurm and PBS job schedulers.

## 🚀 HPC Features

The NASA Lunar Pipeline is designed with HPC capabilities:

- **GPU Acceleration**: CUDA-enabled super resolution processing
- **Multi-Node Processing**: MPI support for distributed computing
- **Parallel Processing**: Multi-threaded batch processing
- **Memory Optimization**: Efficient resource utilization
- **Cluster Integration**: Native support for Slurm and PBS

## 📁 HPC Scripts Overview

### **Job Submission Scripts**

1. **`slurm_submit.sh`** - Single-node Slurm job
2. **`pbs_submit.sh`** - Single-node PBS/Torque job  
3. **`slurm_multi_node.sh`** - Multi-node Slurm job with MPI
4. **`submit_job.sh`** - Interactive job submission helper

### **Configuration Files**

- **`config_hpc.json`** - HPC-optimized configuration
- **`config_multi_node.json`** - Multi-node configuration

## 🎯 Quick Start

### **1. Single Node Job (Slurm)**

```bash
# Make script executable
chmod +x hpc/slurm_submit.sh

# Submit job
sbatch hpc/slurm_submit.sh
```

### **2. Single Node Job (PBS)**

```bash
# Make script executable
chmod +x hpc/pbs_submit.sh

# Submit job
qsub hpc/pbs_submit.sh
```

### **3. Multi-Node Job (Slurm)**

```bash
# Make script executable
chmod +x hpc/slurm_multi_node.sh

# Submit job
sbatch hpc/slurm_multi_node.sh
```

### **4. Interactive Job Submission**

```bash
# Make helper executable
chmod +x hpc/submit_job.sh

# Submit custom job
./hpc/submit_job.sh -t slurm -n 2 -c 32 -g 4 -e your.email@institution.edu
```

## ⚙️ Configuration

### **HPC Configuration Parameters**

```json
{
  "batch_size": 16,
  "max_workers": 16,
  "super_resolution": {
    "scale_factor": 2,
    "model_path": null
  },
  "output_format": "png",
  "quality_metrics": true,
  "gpu_memory_limit": 0.9,
  "hpc_mode": true,
  "parallel_processing": true,
  "multi_node": false,
  "mpi_enabled": false
}
```

### **Resource Requirements**

| Resource | Single Node | Multi-Node |
|----------|-------------|------------|
| **Nodes** | 1 | 4+ |
| **CPUs** | 16-32 | 8 per node |
| **Memory** | 64-128GB | 32GB per node |
| **GPUs** | 2-4 | 1 per node |
| **Wall Time** | 24 hours | 48 hours |

## 🔧 Customization

### **Modifying Job Scripts**

1. **Email Notifications**: Update `--mail-user` in scripts
2. **Module Versions**: Adjust module load commands for your cluster
3. **Partition Names**: Change partition names to match your cluster
4. **Data Paths**: Modify input/output directory paths

### **Example: Custom Slurm Job**

```bash
#!/bin/bash
#SBATCH --job-name=my_lunar_job
#SBATCH --output=logs/my_job_%j.out
#SBATCH --error=logs/my_job_%j.err
#SBATCH --time=12:00:00
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=1
#SBATCH --cpus-per-task=24
#SBATCH --mem=96G
#SBATCH --gres=gpu:3
#SBATCH --partition=my_gpu_partition
#SBATCH --mail-type=ALL
#SBATCH --mail-user=my.email@institution.edu

# Your custom processing logic here
python main.py --input /path/to/input --output /path/to/output
```

## 📊 Monitoring and Management

### **Job Status Commands**

#### **Slurm**
```bash
# Check job status
squeue -u $USER

# Check job details
scontrol show job <job_id>

# Cancel job
scancel <job_id>

# View job output
tail -f logs/nasa_lunar_<job_id>.out
```

#### **PBS**
```bash
# Check job status
qstat -u $USER

# Check job details
qstat -f <job_id>

# Cancel job
qdel <job_id>

# View job output
tail -f logs/nasa_lunar_<job_id>.out
```

### **Resource Monitoring**

```bash
# Monitor GPU usage
nvidia-smi

# Monitor CPU and memory
htop

# Monitor disk usage
df -h /scratch/$USER
```

## 🐛 Troubleshooting

### **Common Issues**

1. **Module Not Found**
   ```bash
   # Check available modules
   module avail
   
   # Load correct module version
   module load cuda/11.8
   ```

2. **GPU Memory Issues**
   ```bash
   # Reduce batch size in config
   "batch_size": 8
   
   # Reduce GPU memory limit
   "gpu_memory_limit": 0.7
   ```

3. **Permission Denied**
   ```bash
   # Make scripts executable
   chmod +x hpc/*.sh
   
   # Check file permissions
   ls -la hpc/
   ```

4. **Out of Memory**
   ```bash
   # Increase memory request
   #SBATCH --mem=128G
   
   # Reduce parallel workers
   "max_workers": 8
   ```

### **Debug Mode**

Enable debug logging by modifying the job scripts:

```bash
# Add debug environment variable
export PYTHONPATH="${PYTHONPATH}:${PWD}"
export LOG_LEVEL=DEBUG

# Run with verbose output
python main.py --verbose --debug
```

## 🚀 Performance Optimization

### **Single Node Optimization**

1. **GPU Utilization**: Use multiple GPUs with `CUDA_VISIBLE_DEVICES`
2. **Memory Management**: Optimize batch size for available memory
3. **CPU Threading**: Set `OMP_NUM_THREADS` to available cores

### **Multi-Node Optimization**

1. **Load Balancing**: Distribute work evenly across nodes
2. **Communication**: Minimize inter-node data transfer
3. **Synchronization**: Use efficient MPI collective operations

### **Benchmarking**

```bash
# Run performance benchmark
python -m src.benchmark --nodes 4 --gpus 8 --batch-size 32

# Generate performance report
python -m src.benchmark --report --output performance_report.html
```

## 📋 Best Practices

### **Job Submission**

1. **Test Locally**: Verify scripts work on login node first
2. **Resource Estimation**: Request appropriate resources
3. **Error Handling**: Always check exit codes and logs
4. **Cleanup**: Remove temporary files after completion

### **Data Management**

1. **Scratch Storage**: Use `/scratch/$USER` for temporary data
2. **Input Validation**: Verify input data before submission
3. **Output Organization**: Structure output directories logically
4. **Backup Strategy**: Keep important results in persistent storage

### **Monitoring**

1. **Regular Checks**: Monitor job progress periodically
2. **Resource Usage**: Track CPU, memory, and GPU utilization
3. **Log Analysis**: Review output logs for errors
4. **Performance Metrics**: Collect timing and throughput data

## 🔗 Integration with Other Tools

### **Containerization**

```bash
# Build Docker image
docker build -t nasa-lunar-pipeline .

# Run with Singularity on HPC
singularity exec nasa-lunar-pipeline.sif python main.py
```

### **Workflow Management**

```bash
# Snakemake integration
snakemake --cluster "sbatch --cpus-per-task {threads}" --jobs 10

# Nextflow integration
nextflow run lunar_pipeline.nf -with-slurm
```

### **Data Transfer**

```bash
# Transfer data to cluster
rsync -avz lunar_images/ user@cluster:/scratch/user/lunar_data/input/

# Transfer results from cluster
rsync -avz user@cluster:/scratch/user/lunar_data/output/ results/
```

## 📞 Support

### **Getting Help**

1. **Cluster Documentation**: Check your institution's HPC documentation
2. **System Administrators**: Contact cluster support team
3. **Community Forums**: Post questions on relevant forums
4. **Issue Tracker**: Report bugs through project issue tracker

### **Useful Commands**

```bash
# Check cluster status
sinfo  # Slurm
pbsnodes  # PBS

# Check queue status
squeue  # Slurm
qstat -q  # PBS

# Check user limits
sacctmgr show user $USER  # Slurm
qmgr -c "print user @default"  # PBS
```

## 📚 Additional Resources

- [Slurm Documentation](https://slurm.schedmd.com/)
- [PBS Professional Documentation](https://www.altair.com/pbs-professional/)
- [OpenMPI Documentation](https://www.open-mpi.org/)
- [CUDA Programming Guide](https://docs.nvidia.com/cuda/)
- [Python Multiprocessing](https://docs.python.org/3/library/multiprocessing.html)

---

**Note**: Always check your specific cluster's configuration and adjust scripts accordingly. Different HPC centers may have different module names, partition names, and resource limits. 