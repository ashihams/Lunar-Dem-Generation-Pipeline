#!/bin/bash
# NASA Lunar Pipeline - HPC Job Submission Helper
# This script helps you submit jobs with different configurations

set -e

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Default values
JOB_TYPE="slurm"
NODES=1
CPUS_PER_TASK=16
MEM="64G"
GPUS=2
TIME="24:00:00"
PARTITION="gpu"
EMAIL="your.email@institution.edu"

# Function to print usage
print_usage() {
    echo -e "${BLUE}NASA Lunar Pipeline - HPC Job Submission Helper${NC}"
    echo ""
    echo "Usage: $0 [OPTIONS]"
    echo ""
    echo "Options:"
    echo "  -t, --type TYPE        Job type: slurm, pbs, multi (default: slurm)"
    echo "  -n, --nodes N          Number of nodes (default: 1)"
    echo "  -c, --cpus N           CPUs per task (default: 16)"
    echo "  -m, --mem MEM          Memory per node (default: 64G)"
    echo "  -g, --gpus N           Number of GPUs per node (default: 2)"
    echo "  -w, --walltime TIME    Wall time (default: 24:00:00)"
    echo "  -p, --partition PART   Partition name (default: gpu)"
    echo "  -e, --email EMAIL      Email for notifications (default: your.email@institution.edu)"
    echo "  -h, --help             Show this help message"
    echo ""
    echo "Examples:"
    echo "  $0 -t slurm -n 1 -c 32 -g 4                    # Single node, high resources"
    echo "  $0 -t multi -n 4 -c 8 -g 1                     # Multi-node processing"
    echo "  $0 -t pbs -n 2 -c 16 -g 2 -m 128G              # PBS cluster, 2 nodes"
    echo ""
}

# Function to validate email
validate_email() {
    if [[ ! $1 =~ ^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$ ]]; then
        echo -e "${RED}Error: Invalid email format: $1${NC}"
        exit 1
    fi
}

# Function to create custom job script
create_custom_script() {
    local script_name="custom_job_${JOB_TYPE}.sh"
    
    case $JOB_TYPE in
        "slurm")
            cat > $script_name << EOF
#!/bin/bash
#SBATCH --job-name=nasa_lunar_custom
#SBATCH --output=logs/nasa_lunar_custom_%j.out
#SBATCH --error=logs/nasa_lunar_custom_%j.err
#SBATCH --time=$TIME
#SBATCH --nodes=$NODES
#SBATCH --ntasks-per-node=1
#SBATCH --cpus-per-task=$CPUS_PER_TASK
#SBATCH --mem=$MEM
#SBATCH --gres=gpu:$GPUS
#SBATCH --partition=$PARTITION
#SBATCH --mail-type=ALL
#SBATCH --mail-user=$EMAIL

# Custom NASA Lunar Pipeline Job
# Generated on: $(date)

echo "=========================================="
echo "NASA Lunar Pipeline - Custom Job Started"
echo "Job ID: \$SLURM_JOB_ID"
echo "Nodes: \$SLURM_NODELIST"
echo "CPUs: \$SLURM_CPUS_PER_TASK"
echo "GPUs: \$SLURM_GPUS"
echo "Memory: $MEM"
echo "Time: \$(date)"
echo "=========================================="

# Load modules (customize for your cluster)
module purge
module load cuda/11.8
module load python/3.9
module load opencv/4.7.0

# Set environment
export CUDA_VISIBLE_DEVICES=\$(seq -s, 0 \$((SLURM_GPUS-1)))
export OMP_NUM_THREADS=\$SLURM_CPUS_PER_TASK
export PYTHONPATH="\${PYTHONPATH}:\${PWD}"

# Create directories
mkdir -p logs
mkdir -p /scratch/\${USER}/lunar_data/{input,output,temp}

# Install dependencies
pip install --user torch torchvision opencv-python numpy pillow

# Create configuration
cat > config_custom.json << 'CONFIG_EOF'
{
  "batch_size": $((CPUS_PER_TASK * 2)),
  "max_workers": $CPUS_PER_TASK,
  "super_resolution": {
    "scale_factor": 2,
    "model_path": null
  },
  "output_format": "png",
  "quality_metrics": true,
  "gpu_memory_limit": 0.9,
  "hpc_mode": true,
  "parallel_processing": true
}
CONFIG_EOF

# Run pipeline
python main.py --input /scratch/\${USER}/lunar_data/input \\
               --output /scratch/\${USER}/lunar_data/output \\
               --config config_custom.json \\
               --temp /scratch/\${USER}/lunar_data/temp

# Cleanup
rm -rf /scratch/\${USER}/lunar_data/temp/*

echo "Custom job completed successfully!"
EOF
            ;;
        "pbs")
            cat > $script_name << EOF
#!/bin/bash
#PBS -N nasa_lunar_custom
#PBS -o logs/nasa_lunar_custom_\${PBS_JOBID}.out
#PBS -e logs/nasa_lunar_custom_\${PBS_JOBID}.err
#PBS -l walltime=$TIME
#PBS -l nodes=$NODES:ppn=$CPUS_PER_TASK
#PBS -l mem=$MEM
#PBS -l gpus=$GPUS
#PBS -q $PARTITION
#PBS -m abe
#PBS -M $EMAIL

# Custom NASA Lunar Pipeline Job
# Generated on: $(date)

cd \$PBS_O_WORKDIR

echo "=========================================="
echo "NASA Lunar Pipeline - Custom PBS Job Started"
echo "Job ID: \$PBS_JOBID"
echo "Nodes: \$PBS_NODEFILE"
echo "CPUs: $CPUS_PER_TASK"
echo "GPUs: $GPUS"
echo "Memory: $MEM"
echo "Time: \$(date)"
echo "=========================================="

# Load modules
module purge
module load cuda/11.8
module load python/3.9
module load opencv/4.7.0

# Set environment
export CUDA_VISIBLE_DEVICES=\$(seq -s, 0 $((GPUS-1)))
export OMP_NUM_THREADS=$CPUS_PER_TASK
export PYTHONPATH="\${PYTHONPATH}:\${PWD}"

# Create directories
mkdir -p logs
mkdir -p /scratch/\${USER}/lunar_data/{input,output,temp}

# Install dependencies
pip install --user torch torchvision opencv-python numpy pillow

# Create configuration
cat > config_custom.json << 'CONFIG_EOF'
{
  "batch_size": $((CPUS_PER_TASK * 2)),
  "max_workers": $CPUS_PER_TASK,
  "super_resolution": {
    "scale_factor": 2,
    "model_path": null
  },
  "output_format": "png",
  "quality_metrics": true,
  "gpu_memory_limit": 0.9,
  "hpc_mode": true,
  "parallel_processing": true
}
CONFIG_EOF

# Run pipeline
python main.py --input /scratch/\${USER}/lunar_data/input \\
               --output /scratch/\${USER}/lunar_data/output \\
               --config config_custom.json \\
               --temp /scratch/\${USER}/lunar_data/temp

# Cleanup
rm -rf /scratch/\${USER}/lunar_data/temp/*

echo "Custom PBS job completed successfully!"
EOF
            ;;
        "multi")
            cat > $script_name << EOF
#!/bin/bash
#SBATCH --job-name=nasa_lunar_multi_custom
#SBATCH --output=logs/nasa_lunar_multi_custom_%j.out
#SBATCH --error=logs/nasa_lunar_multi_custom_%j.err
#SBATCH --time=$TIME
#SBATCH --nodes=$NODES
#SBATCH --ntasks-per-node=4
#SBATCH --cpus-per-task=$((CPUS_PER_TASK/4))
#SBATCH --mem=$MEM
#SBATCH --gres=gpu:$GPUS
#SBATCH --partition=$PARTITION
#SBATCH --mail-type=ALL
#SBATCH --mail-user=$EMAIL

# Custom Multi-Node NASA Lunar Pipeline Job
# Generated on: $(date)

echo "=========================================="
echo "NASA Lunar Pipeline - Custom Multi-Node Job Started"
echo "Job ID: \$SLURM_JOB_ID"
echo "Nodes: \$SLURM_NODELIST"
echo "Total Tasks: \$SLURM_NTASKS"
echo "CPUs per Task: \$SLURM_CPUS_PER_TASK"
echo "GPUs: $GPUS"
echo "Time: \$(date)"
echo "=========================================="

# Load modules
module purge
module load cuda/11.8
module load python/3.9
module load opencv/4.7.0
module load mpi/openmpi-4.1.1

# Set environment
export OMP_NUM_THREADS=\$SLURM_CPUS_PER_TASK
export PYTHONPATH="\${PYTHONPATH}:\${PWD}"

# Create directories
mkdir -p logs
mkdir -p /scratch/\${USER}/lunar_data/{input,output,temp}

# Install dependencies on all nodes
srun pip install --user torch torchvision opencv-python numpy pillow mpi4py

# Create configuration
cat > config_multi_custom.json << 'CONFIG_EOF'
{
  "batch_size": $((CPUS_PER_TASK * 4)),
  "max_workers": \$SLURM_CPUS_PER_TASK,
  "super_resolution": {
    "scale_factor": 2,
    "model_path": null
  },
  "output_format": "png",
  "quality_metrics": true,
  "gpu_memory_limit": 0.8,
  "hpc_mode": true,
  "parallel_processing": true,
  "multi_node": true,
  "mpi_enabled": true
}
CONFIG_EOF

# Run pipeline with MPI
srun python main.py --input /scratch/\${USER}/lunar_data/input \\
                   --output /scratch/\${USER}/lunar_data/output \\
                   --config config_multi_custom.json \\
                   --temp /scratch/\${USER}/lunar_data/temp \\
                   --mpi

# Cleanup on all nodes
srun rm -rf /scratch/\${USER}/lunar_data/temp/*

echo "Custom multi-node job completed successfully!"
EOF
            ;;
    esac
    
    chmod +x $script_name
    echo -e "${GREEN}Created custom job script: $script_name${NC}"
}

# Function to submit job
submit_job() {
    local script_name="custom_job_${JOB_TYPE}.sh"
    
    if [ ! -f "$script_name" ]; then
        echo -e "${RED}Error: Job script $script_name not found!${NC}"
        exit 1
    fi
    
    echo -e "${BLUE}Submitting job with configuration:${NC}"
    echo "  Job Type: $JOB_TYPE"
    echo "  Nodes: $NODES"
    echo "  CPUs per Task: $CPUS_PER_TASK"
    echo "  Memory: $MEM"
    echo "  GPUs: $GPUS"
    echo "  Wall Time: $TIME"
    echo "  Partition: $PARTITION"
    echo "  Email: $EMAIL"
    echo ""
    
    case $JOB_TYPE in
        "slurm"|"multi")
            echo -e "${YELLOW}Submitting to Slurm...${NC}"
            sbatch $script_name
            ;;
        "pbs")
            echo -e "${YELLOW}Submitting to PBS...${NC}"
            qsub $script_name
            ;;
    esac
    
    echo -e "${GREEN}Job submitted successfully!${NC}"
}

# Parse command line arguments
while [[ $# -gt 0 ]]; do
    case $1 in
        -t|--type)
            JOB_TYPE="$2"
            shift 2
            ;;
        -n|--nodes)
            NODES="$2"
            shift 2
            ;;
        -c|--cpus)
            CPUS_PER_TASK="$2"
            shift 2
            ;;
        -m|--mem)
            MEM="$2"
            shift 2
            ;;
        -g|--gpus)
            GPUS="$2"
            shift 2
            ;;
        -w|--walltime)
            TIME="$2"
            shift 2
            ;;
        -p|--partition)
            PARTITION="$2"
            shift 2
            ;;
        -e|--email)
            EMAIL="$2"
            shift 2
            ;;
        -h|--help)
            print_usage
            exit 0
            ;;
        *)
            echo -e "${RED}Unknown option: $1${NC}"
            print_usage
            exit 1
            ;;
    esac
done

# Validate inputs
if [[ ! "$JOB_TYPE" =~ ^(slurm|pbs|multi)$ ]]; then
    echo -e "${RED}Error: Invalid job type. Must be slurm, pbs, or multi${NC}"
    exit 1
fi

if [[ ! "$NODES" =~ ^[0-9]+$ ]] || [ "$NODES" -lt 1 ]; then
    echo -e "${RED}Error: Invalid number of nodes${NC}"
    exit 1
fi

if [[ ! "$CPUS_PER_TASK" =~ ^[0-9]+$ ]] || [ "$CPUS_PER_TASK" -lt 1 ]; then
    echo -e "${RED}Error: Invalid number of CPUs per task${NC}"
    exit 1
fi

if [[ ! "$GPUS" =~ ^[0-9]+$ ]] || [ "$GPUS" -lt 0 ]; then
    echo -e "${RED}Error: Invalid number of GPUs${NC}"
    exit 1
fi

validate_email "$EMAIL"

# Create and submit job
echo -e "${BLUE}Creating custom job script...${NC}"
create_custom_script

echo -e "${BLUE}Submitting job...${NC}"
submit_job 