#!/bin/bash
#SBATCH --job-name=nasa_lunar_multi
#SBATCH --output=logs/nasa_lunar_multi_%j.out
#SBATCH --error=logs/nasa_lunar_multi_%j.err
#SBATCH --time=48:00:00
#SBATCH --nodes=4
#SBATCH --ntasks-per-node=4
#SBATCH --cpus-per-task=8
#SBATCH --mem=32G
#SBATCH --gres=gpu:1
#SBATCH --partition=compute
#SBATCH --mail-type=ALL
#SBATCH --mail-user=your.email@institution.edu

# NASA Lunar Pipeline - Multi-Node Slurm Job Submission Script
# This script runs the lunar pipeline across multiple nodes for large-scale processing

echo "=========================================="
echo "NASA Lunar Pipeline - Multi-Node Job Started"
echo "Job ID: $SLURM_JOB_ID"
echo "Nodes: $SLURM_NODELIST"
echo "Total Tasks: $SLURM_NTASKS"
echo "Time: $(date)"
echo "=========================================="

# Load required modules
module purge
module load cuda/11.8
module load python/3.9
module load opencv/4.7.0
module load mpi/openmpi-4.1.1

# Create logs directory
mkdir -p logs

# Set environment variables
export OMP_NUM_THREADS=$SLURM_CPUS_PER_TASK
export PYTHONPATH="${PYTHONPATH}:${PWD}"

# Install dependencies
echo "Installing dependencies on all nodes..."
srun pip install --user torch torchvision opencv-python numpy pillow mpi4py

# Create HPC configuration
cat > config_multi_node.json << EOF
{
  "batch_size": 32,
  "max_workers": $SLURM_CPUS_PER_TASK,
  "super_resolution": {
    "scale_factor": 2,
    "model_path": null
  },
  "output_format": "png",
  "quality_metrics": true,
  "gpu_memory_limit": 0.8,
  "hpc_mode": true,
  "parallel_processing": true,
  "multi_node": true,
  "mpi_enabled": true
}
EOF

# Set data directories
BASE_DIR="/scratch/${USER}/lunar_data"
INPUT_DIR="${BASE_DIR}/input"
OUTPUT_DIR="${BASE_DIR}/output"
TEMP_DIR="${BASE_DIR}/temp"

# Create directories on all nodes
srun mkdir -p $INPUT_DIR $OUTPUT_DIR $TEMP_DIR

# Check input data
if [ ! -d "$INPUT_DIR" ] || [ -z "$(ls -A $INPUT_DIR)" ]; then
    echo "ERROR: Input directory $INPUT_DIR is empty or doesn't exist!"
    echo "Please copy your lunar images to: $INPUT_DIR"
    exit 1
fi

echo "Input directory: $INPUT_DIR"
echo "Output directory: $OUTPUT_DIR"
echo "Temporary directory: $TEMP_DIR"

# Get node information
NODE_LIST=$(scontrol show hostnames $SLURM_JODELIST)
echo "Processing on nodes: $NODE_LIST"

# Run the pipeline with MPI support
echo "Starting multi-node NASA Lunar Pipeline processing..."
srun python main.py --input $INPUT_DIR --output $OUTPUT_DIR --config config_multi_node.json --temp $TEMP_DIR --mpi

# Check exit status
if [ $? -eq 0 ]; then
    echo "=========================================="
    echo "Multi-Node NASA Lunar Pipeline completed successfully!"
    echo "Output saved to: $OUTPUT_DIR"
    echo "Job completed at: $(date)"
    echo "=========================================="
else
    echo "=========================================="
    echo "Multi-Node NASA Lunar Pipeline failed with exit code $?"
    echo "Check error logs for details"
    echo "=========================================="
    exit 1
fi

# Clean up temporary files on all nodes
echo "Cleaning up temporary files..."
srun rm -rf $TEMP_DIR/*

echo "Multi-node job completed successfully!" 