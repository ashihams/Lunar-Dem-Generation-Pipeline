#!/bin/bash
#SBATCH --job-name=nasa_lunar_custom
#SBATCH --output=logs/nasa_lunar_custom_%j.out
#SBATCH --error=logs/nasa_lunar_custom_%j.err
#SBATCH --time=24:00:00
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=1
#SBATCH --cpus-per-task=16
#SBATCH --mem=64G
#SBATCH --gres=gpu:2
#SBATCH --partition=gpu
#SBATCH --mail-type=ALL
#SBATCH --mail-user=your.email@institution.edu

# Custom NASA Lunar Pipeline Job
# Generated on: Mon Aug 25 00:13:14 IST 2025

echo "=========================================="
echo "NASA Lunar Pipeline - Custom Job Started"
echo "Job ID: $SLURM_JOB_ID"
echo "Nodes: $SLURM_NODELIST"
echo "CPUs: $SLURM_CPUS_PER_TASK"
echo "GPUs: $SLURM_GPUS"
echo "Memory: 64G"
echo "Time: $(date)"
echo "=========================================="

# Load modules (customize for your cluster)
module purge
module load cuda/11.8
module load python/3.9
module load opencv/4.7.0

# Set environment
export CUDA_VISIBLE_DEVICES=$(seq -s, 0 $((SLURM_GPUS-1)))
export OMP_NUM_THREADS=$SLURM_CPUS_PER_TASK
export PYTHONPATH="${PYTHONPATH}:${PWD}"

# Create directories
mkdir -p logs
mkdir -p /scratch/${USER}/lunar_data/{input,output,temp}

# Install dependencies
pip install --user torch torchvision opencv-python numpy pillow

# Create configuration
cat > config_custom.json << 'CONFIG_EOF'
{
  "batch_size": 32,
  "max_workers": 16,
  "super_resolution": {
    "scale_factor": 2,
    "model_path": null
  },
  "output_format": "png",
  "quality_metrics": true,
  "gpu_memory_limit": 0.9,
  "hpc_mode": true,
  "parallel_processing": true
}
CONFIG_EOF

# Run pipeline
python main.py --input /scratch/${USER}/lunar_data/input \
               --output /scratch/${USER}/lunar_data/output \
               --config config_custom.json \
               --temp /scratch/${USER}/lunar_data/temp

# Cleanup
rm -rf /scratch/${USER}/lunar_data/temp/*

echo "Custom job completed successfully!"
