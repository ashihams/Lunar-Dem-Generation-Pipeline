#!/bin/bash
#PBS -N nasa_lunar_pipeline
#PBS -o logs/nasa_lunar_${PBS_JOBID}.out
#PBS -e logs/nasa_lunar_${PBS_JOBID}.err
#PBS -l walltime=24:00:00
#PBS -l nodes=1:ppn=16
#PBS -l mem=64gb
#PBS -l gpus=2
#PBS -q gpu
#PBS -m abe
#PBS -M your.email@institution.edu

# NASA Lunar Pipeline - PBS Job Submission Script
# This script submits the lunar pipeline processing job to a PBS/Torque cluster

echo "=========================================="
echo "NASA Lunar Pipeline - PBS Job Started"
echo "Job ID: $PBS_JOBID"
echo "Node: $PBS_NODEFILE"
echo "Time: $(date)"
echo "=========================================="

# Change to submission directory
cd $PBS_O_WORKDIR

# Load required modules (adjust based on your cluster)
module purge
module load cuda/11.8
module load python/3.9
module load opencv/4.7.0

# Create logs directory if it doesn't exist
mkdir -p logs

# Set environment variables
export CUDA_VISIBLE_DEVICES=0,1
export OMP_NUM_THREADS=16
export PYTHONPATH="${PYTHONPATH}:${PWD}"

# Activate virtual environment if using one
# source /path/to/your/venv/bin/activate

# Install dependencies if needed
echo "Installing/updating dependencies..."
pip install --user torch torchvision opencv-python numpy pillow

# Create configuration for HPC environment
cat > config_hpc.json << EOF
{
  "batch_size": 16,
  "max_workers": 16,
  "super_resolution": {
    "scale_factor": 2,
    "model_path": null
  },
  "output_format": "png",
  "quality_metrics": true,
  "gpu_memory_limit": 0.9,
  "hpc_mode": true,
  "parallel_processing": true
}
EOF

# Set input/output paths (modify as needed)
INPUT_DIR="/scratch/${USER}/lunar_data/input"
OUTPUT_DIR="/scratch/${USER}/lunar_data/output"
TEMP_DIR="/scratch/${USER}/lunar_data/temp"

# Create directories
mkdir -p $INPUT_DIR $OUTPUT_DIR $TEMP_DIR

# Check if input data exists
if [ ! -d "$INPUT_DIR" ] || [ -z "$(ls -A $INPUT_DIR)" ]; then
    echo "ERROR: Input directory $INPUT_DIR is empty or doesn't exist!"
    echo "Please copy your lunar images to: $INPUT_DIR"
    exit 1
fi

echo "Input directory: $INPUT_DIR"
echo "Output directory: $OUTPUT_DIR"
echo "Temporary directory: $TEMP_DIR"

# Run the pipeline
echo "Starting NASA Lunar Pipeline processing..."
python main.py --input $INPUT_DIR --output $OUTPUT_DIR --config config_hpc.json --temp $TEMP_DIR

# Check exit status
if [ $? -eq 0 ]; then
    echo "=========================================="
    echo "NASA Lunar Pipeline completed successfully!"
    echo "Output saved to: $OUTPUT_DIR"
    echo "Job completed at: $(date)"
    echo "=========================================="
else
    echo "=========================================="
    echo "NASA Lunar Pipeline failed with exit code $?"
    echo "Check error logs for details"
    echo "=========================================="
    exit 1
fi

# Clean up temporary files
echo "Cleaning up temporary files..."
rm -rf $TEMP_DIR/*

echo "Job completed successfully!" 